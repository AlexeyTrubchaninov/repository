<html>
<head>
<META http-equiv=Content-Type content="text/html; charset=Windows-1251">
<title>Путь к текущему каталогу от корня</title>
</head>
<body>
<?php
echo 'Полный путь к каталогу: ';
echo $_SERVER['DOCUMENT_ROOT'];
echo '/';
?>
</body>
</html>