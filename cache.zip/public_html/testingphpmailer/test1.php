<?php
require("/home/c/cm13906/public_html/testingphpmailer/PHPMailer_5.2.0/class.phpmailer.php");

$mail = new PHPMailer();

$mail->IsSMTP();                                      // set mailer to use SMTP
$mail->Host = "smtp.gmail.com";  // specify main and backup server
$mail->SMTPDebug  = "1";
$mail->SMTPAuth = "true";     // turn on SMTP authentication
$mail->SMTPSecure = "ssl";
$mail->Port = "465";
$mail->Username = "testsmartbutton04@gmail.com";  // SMTP username
$mail->Password = "test0912"; // SMTP password

$mail->From = "testsmartbutton04@gmail.com";
$mail->FromName = "Alexey Trubchaninov";

$mail->AddAddress("alexey.trubchaninov@gmail.com");                  // name is optional


$mail->WordWrap = 50;                                 // set word wrap to 50 characters
$mail->IsHTML(true);                                  // set email format to HTML

$mail->Subject = "Delivery Request";
$mail->Body    = "Hello, this is a test";
$mail->AltBody = "Test";

if(!$mail->Send())
{
   echo "Message could not be sent. <p>";
   echo "Mailer Error: " . $mail->ErrorInfo;
   exit;
}

echo "Message has been sent";
?>